"""anilist-cli package."""

__version__ = "0.1.0"
